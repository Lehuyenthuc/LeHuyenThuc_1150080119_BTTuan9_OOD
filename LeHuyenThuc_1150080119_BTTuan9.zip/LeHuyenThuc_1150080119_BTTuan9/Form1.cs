﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LeHuyenThuc_1150080119_BTTuan9
{
    public partial class Form1 : Form
    {
        // Dùng |DataDirectory| để tránh lỗi đường dẫn khi run
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\QuanLyBanSach.mdf;Integrated Security=True";

        private SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'quanLyBanSachDataSet.NhaXuatBan' table. You can move, or remove it, as needed.
            this.nhaXuatBanTableAdapter.Fill(this.quanLyBanSachDataSet.NhaXuatBan);
            // Có thể dùng để load dữ liệu mặc định nếu muốn
        }

        // Mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);

            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // Đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // Sự kiện nhấn nút hiển thị dữ liệu
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();

                // Lấy tất cả dữ liệu từ bảng NhaXuatBan
                string sql = "SELECT * FROM NhaXuatBan";

                SqlDataAdapter adapter = new SqlDataAdapter(sql, sqlCon);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "NhaXuatBan");

                // Gán DataTable vào DataGridView
                dgvDanhSach.DataSource = ds.Tables["NhaXuatBan"];

                DongKetNoi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}
